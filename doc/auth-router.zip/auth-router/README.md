# 权限控制

- 视频地址：[【直播回放】Vue路由权限『前后端全解析』](https://www.bilibili.com/video/BV11A411J7z5)
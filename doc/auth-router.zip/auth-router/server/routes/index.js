const router = require('koa-router')()

const routers = require('../data/routers')
const users = require('../data/users')

router.post('/user_router_auth', async (ctx, next) => {
  const { uid } = ctx.request.body
  if (uid) {
    let authRouterInfo = []
    const userInfo = users.filter(user => user.id == uid)[0]
    console.log(userInfo, 'userInfo');
    userInfo.auth.map(rid => {
      routers.map(router => {
        if (rid === router.id) {
          authRouterInfo.push(router)
        }
      })
    })
    ctx.body = authRouterInfo
  } else {
    next()
  }
})

module.exports = router

module.exports = [
  {
    id: 1,
    name: 'zhangsan',
    auth: [2, 3, 6, 7]
  },
  {
    id: 2,
    name: 'lisi',
    auth: [2, 3, 5, 6, 7, 8]
  }, {
    id: 3,
    name: 'wangwu',
    auth: [2, 3, 4,  5, 6, 7, 8]
  }
]
<template>
  <div id="app">
    <m-header />
    <side-bar />
    <page-board />
  </div>
</template>

<script>
import MHeader from '@/components/Header';
import SideBar from '@/components/SideBar';
import PageBoard from '@/components/PageBoard';

export default {
  name: 'App',
  components: {
    MHeader,
    SideBar,
    PageBoard
  },
  mounted() {}
};
</script>

export default {
  uid: 1,
  hasAuth: false,
  userRouters: []
}
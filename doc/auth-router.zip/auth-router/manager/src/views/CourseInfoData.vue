<template>
  <div>
    <h3>课程数据</h3>
  </div>
</template>

<script>
export default {
  name: 'CourseInfoData'
};
</script>
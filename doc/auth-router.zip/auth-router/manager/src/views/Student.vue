<template>
  <div>
    <h1>学生管理</h1>
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'Student'
};
</script>
<template>
  <div>
    <h1>课程管理</h1>
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'Course'
};
</script>
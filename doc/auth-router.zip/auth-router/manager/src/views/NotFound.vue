<template>
  <h1>404 Not Found</h1>
</template>

<script>
export default {
  name: 'NotFound'
}
</script>
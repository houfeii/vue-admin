<template>
  <h2>增加课程</h2>
</template>

<script>
export default {
  name: 'CourseAdd'
};
</script>
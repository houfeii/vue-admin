<template>
  <div>
    <h2>课程操作</h2>
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'CourseOprate'
};
</script>
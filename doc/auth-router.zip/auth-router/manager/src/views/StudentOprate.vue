<template>
  <h2>操作学生</h2>
</template>

<script>
export default {
  name: 'StudentOprate'
};
</script>
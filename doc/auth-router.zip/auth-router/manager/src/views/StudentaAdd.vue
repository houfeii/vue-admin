<template>
  <div>
    <h2>增加学生</h2>
  </div>
</template>

<script>
export default {
  name: 'StudentaAdd'
};
</script>
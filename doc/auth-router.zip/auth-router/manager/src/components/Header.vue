<template>
  <header class="m-header">
    LOGO
  </header>
</template>

<script>
export default {
  name: 'MHeader'
};
</script>

<style scoped lang="scss">
.m-header {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 2;
  width: 100%;
  height: 60px;
  background-color: aqua;
  display: flex;
  align-items: center;
}
</style>

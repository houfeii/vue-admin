<template>
  <div class="side-bar">
    <ul>
      <li>
        <router-link to='/'>首页</router-link>
      </li>
    </ul>
    <span
      v-for="(item, index) of $store.state.userRouters"
      :key="index"
    >
      <menu-item
        :key="index"
        :item="item"
      ></menu-item>
    </span>
  </div>
</template>

<script>
import MenuItem from './MenuItem';
export default {
  name: 'SideBar',
  components: {
    MenuItem
  }
};
</script>

<style scoped lang="scss">
.side-bar {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 1;
  width: 200px;
  height: 100%;
  padding-top: 90px;
  box-sizing: border-box;
  background-color: aquamarine;
}
</style>
